#SampleBash
#this rsync command will do it:

    export ssh_server=csitea.net # the domain name or ip if you want 
    export ssh_user=ubuntu # the ssh user to use to
    export src_dir=/home/ubuntu/opt/ # the source dir
    # the full path to the ssh identity file 
    export ssh_idty=~/.ssh/id_rsa.aws-ec2.csitea.net 
    export tgt_dir=/home/me/opt/ # the target dir
    # Action !!!
    rsync -e "ssh -l USERID -i $ssh_idty" -av -r --partial --progress --human-readable \
        --stats $ssh_user@$ssh_server:$src_dir $tgt_dir
    # and check the result
    clear ; find $tgt_dir -type d -maxdepth 1|sort -nr| less