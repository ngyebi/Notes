#!/bin/python
import random
import os
import json

count = os.getenv("FILE_COUNT") or 100
words = [word.strip() for word in open('/usr/share/dict/words').readlines()]

for identifier in range(1, count + 1):
    amount = random.uniform(1.0
id

Django
(base) [ngyebi@vrh7ngyebi src]$ python manage.py createsuperuser
Username (leave blank to use 'ngyebi'): kwesi
Email address: gyamfig@yahoo.com
Password:
Password (again):
Superuser created successfully.
